package com.telerikacademy;

public class Ingredients {
}
