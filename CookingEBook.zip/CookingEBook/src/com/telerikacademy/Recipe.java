package com.telerikacademy;

public class Recipe {
}
