package com.telerikacademy;

public class Review extends Message {
}
