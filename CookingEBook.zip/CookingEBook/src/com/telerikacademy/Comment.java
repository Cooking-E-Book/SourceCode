package com.telerikacademy;

public class Comment extends Message {


}
