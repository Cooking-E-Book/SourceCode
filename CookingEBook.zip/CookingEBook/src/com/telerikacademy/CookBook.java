package com.telerikacademy;

public class CookBook {
    // Application Class


}
